import { category as perma } from './database/perma'
import { category as equipo } from './database/equipo'
import { category as dinamicasReunion } from './database/dinamicasReunion'
import { category as conexion } from './database/conexion'
import { category as conversaciones } from './database/conversaciones'
import { category as mindfulness } from './database/mindfulness'
import { category as reuniones } from './database/reuniones'
import { category as fortalezas } from './database/fortalezas'
import { category as juegos } from './database/juegos'
import { category as comunicacion } from './database/comunicacion'

export const categories = [
  perma,
  equipo,
  dinamicasReunion,
  conexion,
  conversaciones,
  mindfulness,
  reuniones,
  fortalezas,
  juegos,
  comunicacion,
]
  .filter((category) => category.visible)
  .sort((a, b) => a.order - b.order)