import { activities as permaActivities } from './database/perma'
import { activities as equipoActivities } from './database/equipo'
import { activities as dinamicasReunionActivities } from './database/dinamicasReunion'
import { activities as conexionActivities } from './database/conexion'
import { activities as conversacionesActivities } from './database/conversaciones'
import { activities as mindfulnessActivities } from './database/mindfulness'
import { activities as reunionesActivities } from './database/reuniones'
import { activities as fortalezasActivities } from './database/fortalezas'
import { activities as juegosActivities } from './database/juegos'
import { activities as comunicacionActivities } from './database/comunicacion'

export const activities = [
  ...permaActivities,
  ...equipoActivities,
  ...dinamicasReunionActivities,
  ...conexionActivities,
  ...conversacionesActivities,
  ...mindfulnessActivities,
  ...reunionesActivities,
  ...fortalezasActivities,
  ...juegosActivities,
  ...comunicacionActivities,
]