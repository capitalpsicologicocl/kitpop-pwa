export default function Login() {
  return <main id="home">Iniciar sesión</main>
}