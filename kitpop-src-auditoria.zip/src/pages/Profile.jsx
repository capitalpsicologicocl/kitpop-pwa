export default function Profile() {
  return <main id="home">Perfil</main>
}