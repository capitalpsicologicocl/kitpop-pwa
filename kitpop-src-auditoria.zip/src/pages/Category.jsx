import { Link, useParams } from 'react-router-dom'

import { categories } from '../data/categories'
import ActivityList from '../components/categories/ActivityList'

export default function Category() {
  const { slug } = useParams()

  const category = categories.find(
    (item) => item.slug === slug
  )

  if (!category) {
    return (
      <main id="cat-view" className="fade-in">
        <Link to="/" className="back-btn">
          ← Volver
        </Link>

        <h1 className="cv-title">
          Categoría no encontrada
        </h1>

        <p className="cv-desc">
          La categoría que intentas abrir no existe o todavía no está disponible.
        </p>
      </main>
    )
  }

  return (
    <main id="cat-view" className="fade-in">
      <Link to="/" className="back-btn">
        ← Volver
      </Link>

      <h1 className="cv-title">
        {category.title}
      </h1>

      <p className="cv-desc">
        {category.description}
      </p>

      <ActivityList categorySlug={category.slug} />
    </main>
  )
}