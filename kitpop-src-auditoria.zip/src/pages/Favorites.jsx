export default function Favorites() {
  return <main id="home">Favoritos</main>
}