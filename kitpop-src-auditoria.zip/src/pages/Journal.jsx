export default function Journal() {
  return <main id="home">Bitácora</main>
}