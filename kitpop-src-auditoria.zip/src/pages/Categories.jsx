export default function Categories() {
  return <main id="home">Categorías</main>
}