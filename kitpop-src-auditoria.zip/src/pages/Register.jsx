export default function Register() {
  return <main id="home">Registro</main>
}