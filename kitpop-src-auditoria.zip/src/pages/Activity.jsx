export default function Activity() {
  return <main id="act-view">Actividad KitPOP</main>
}