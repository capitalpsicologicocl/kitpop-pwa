import { Link } from 'react-router-dom'
import { categories } from '../../data/categories'

export default function Sidebar({ isOpen, onClose }) {
  return (
    <>
      <div
        className={`kp-menu-backdrop ${isOpen ? 'on' : ''}`}
        onClick={onClose}
      />

      <aside
        className={`kp-menu-drawer ${isOpen ? 'on' : ''}`}
        aria-hidden={!isOpen}
      >
        <div className="kp-menu-head">
          <img src="/kitpop-logo.png" alt="KitPOP de Facilitación" />

          <button
            className="kp-menu-close"
            type="button"
            onClick={onClose}
            aria-label="Cerrar menú"
          >
            ×
          </button>
        </div>

        <div className="kp-auth-box">
          <p className="kp-menu-label">Cuenta KitPOP</p>

          <div className="kp-auth-actions">
            <Link to="/login" onClick={onClose}>Iniciar sesión</Link>
            <Link to="/registro" onClick={onClose}>Registro</Link>
          </div>

          <p className="kp-menu-note">
            Preparado para conectar con Supabase: nombre, mail, contraseña,
            favoritos y bitácoras.
          </p>
        </div>

        <div className="kp-menu-section">
          <p className="kp-menu-label">Buscar actividades</p>

          <input
            className="kp-menu-input"
            placeholder="Buscar por nombre, objetivo o material."
          />

          <div className="kp-menu-filters">
            <select>
              <option value="all">Todas las categorías</option>
              {categories.map((category) => (
                <option key={category.slug} value={category.slug}>
                  {category.name}
                </option>
              ))}
            </select>

            <select>
              <option value="all">Cualquier duración</option>
              <option value="short">Hasta 15 min</option>
              <option value="medium">16 a 35 min</option>
              <option value="long">36 min o más</option>
            </select>

            <select>
              <option value="all">Todas</option>
              <option value="fav">Favoritas</option>
            </select>
          </div>

          <div className="kp-menu-results">
            <p className="kp-menu-empty">
              Escribe una palabra para buscar actividades.
            </p>
          </div>
        </div>

        <div className="kp-menu-section">
          <p className="kp-menu-label">Categorías</p>

          <div className="kp-menu-cats">
            <Link to="/" className="kp-menu-cat-btn" onClick={onClose}>
              Inicio
            </Link>

            {categories.map((category) => (
              <Link
                key={category.slug}
                to={`/categoria/${category.slug}`}
                className="kp-menu-cat-btn"
                onClick={onClose}
              >
                {category.name}
              </Link>
            ))}

            <Link to="/favoritos" className="kp-menu-cat-btn" onClick={onClose}>
              Favoritos
            </Link>

            <Link to="/bitacora" className="kp-menu-cat-btn" onClick={onClose}>
              Bitácora
            </Link>

            <Link to="/perfil" className="kp-menu-cat-btn" onClick={onClose}>
              Perfil
            </Link>
          </div>
        </div>
      </aside>
    </>
  )
}