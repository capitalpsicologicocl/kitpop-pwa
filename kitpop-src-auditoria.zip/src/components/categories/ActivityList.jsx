import { activities } from '../../data/activities'
import ActivityCard from './ActivityCard'

export default function ActivityList({ categorySlug }) {
  const filteredActivities = activities.filter(
    (activity) => activity.categorySlug === categorySlug
  )

  if (filteredActivities.length === 0) {
    return (
      <div className="acts-empty">
        <h3>No hay actividades disponibles.</h3>
        <p>
          Esta categoría aún no tiene actividades cargadas en la aplicación.
        </p>
      </div>
    )
  }

  return (
    <section className="acts-list">
      {filteredActivities.map((activity) => (
        <ActivityCard
          key={activity.slug}
          activity={activity}
        />
      ))}
    </section>
  )
}