import { Link } from 'react-router-dom'

export default function ActivityCard({ activity }) {
  const durationTotal =
    typeof activity.duration === 'object'
      ? activity.duration.total
      : activity.duration

  const modality = Array.isArray(activity.modality)
    ? activity.modality.join(' · ')
    : activity.modality

  const categoryLabel =
    activity.subcategory || activity.categorySlug || 'Actividad'

  return (
    <Link
      to={`/actividad/${activity.slug}`}
      className="act-item"
    >
      <div className="ai-icon">
        <span>✦</span>
      </div>

      <div className="ai-body">
        <p className="ai-cat">
          {categoryLabel}
        </p>

        <h3 className="ai-name">
          {activity.title}
        </h3>

        <p className="ai-desc">
          {activity.description}
        </p>

        <div className="ai-chips">
          {durationTotal !== undefined && (
            <span className="chip">
              {durationTotal} min
            </span>
          )}

          {modality && (
            <span className="chip">
              {modality}
            </span>
          )}
        </div>
      </div>

      <span className="ai-arr">›</span>
    </Link>
  )
}